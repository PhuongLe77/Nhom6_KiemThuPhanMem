from selenium import webdriver
from selenium.webdriver.common.by import By
#from selenium.common.exceptions import NoSuchElementException
import time
driver = webdriver.Chrome(executable_path='venv/chromedriver')
try:
    driver.get("https://nhanvan.vn/")
    driver.implicitly_wait(4)
    driver.find_element(By.XPATH,"//header/div[@id='header']/div[2]/div[1]/div[1]/div[3]/div[1]/div[3]/a[1]").click()
    driver.find_element(By.NAME,"customer[email]").send_keys("thuyhangnguyen4334@gmail.com")
    driver.find_element(By.NAME,"customer[password]").send_keys("123456789")
    time.sleep(3)
    driver.find_element(By.XPATH,"//*[@id='customer_login']/div[3]/div[1]/button").click()

    driver.get("https://nhanvan.vn/products/bitex-but-chi-my-thuat-6b-premium-nhung-dau-pc15-12-cay-hop")

    driver.implicitly_wait(3)

    driver.find_element(By.XPATH,"//*[@id='product']/div[2]/div/div[1]/div/div/div[6]/div[1]/ul/li[4]/a").click()
    driver.find_element(By.XPATH,"//*[@id='startbap_product_reviews']/div[2]/a[2]").click()

    driver.implicitly_wait(7)
    driver.find_element(By.XPATH,"//*[@id='stars']/li[2]/i").click()

    driver.implicitly_wait(3)
    driver.find_element(By.NAME,"review_title").send_keys("Đánh giá sản phẩm")
    driver.find_element(By.NAME,"review_body").send_keys("Sản phẩm không giống mô tả")

    driver.find_element(By.XPATH,"//*[@id='startbap_product_reviews']/div[2]/div[3]/form/input").click()

except:
    print("Loi ngoai le, vui long chay lai")
time.sleep(5)
driver.close()