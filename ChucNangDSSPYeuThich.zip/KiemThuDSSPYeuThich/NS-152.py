import time
from selenium import webdriver
from selenium.webdriver.common.by import By

try:
    driver = webdriver.Chrome(executable_path="venv/chromedriver.exe")
    driver.maximize_window()
    driver.get("https://nhanvan.vn/")
    time.sleep(3)

    #ĐĂNG NHẬP
    driver.find_element(By.XPATH, '//*[@id="header"]/div[2]/div/div/div[3]/div/div[3]/a[1]').click()
    time.sleep(3)
    driver.find_element(By.XPATH, '//*[@id="customer_email"]').send_keys('1954050043thu@ou.edu.vn')
    driver.find_element(By.XPATH, '//*[@id="customer_password"]').send_keys('1954050043thu')
    driver.find_element(By.XPATH, '//*[@id="customer_login"]/div[3]/div[1]/button').submit()
    time.sleep(3)
    #MỞ DANH MỤC SẢN PHẨM
    driver.get("https://nhanvan.vn/collections/all")
    time.sleep(13)

    #CHỌN SẢN PHẨM THUỘC CÙNG DANH MỤC
    #SẢN PHẨM THUỘC DANH MỤC SÁCH KINH DOANH
    dmSach = driver.find_element(By.XPATH,'//*[@id="collection"]/div/div[2]/div/div[1]/div[3]/div/div/div[1]/div[2]/div/ul/li[3]/a')
    dmSach.click()
    time.sleep(3)
    spSach = driver.find_element(By.XPATH,'//*[@id="collection"]/div/div[2]/div/div[2]/div[4]/div[22]/div/div[2]/div[1]/h3/a')
    spSach.click()
    time.sleep(3)
    print(driver.find_element(By.XPATH, '//*[@id="product"]/div[1]/div/div/ol/li[3]/a').text)
    buttonHEART = driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_add"]')
    buttonHEART.click()
    time.sleep(3)

    dmSach = driver.find_element(By.XPATH, '//*[@id="product"]/div[1]/div/div/ol/li[3]/a').click()
    time.sleep(3)
    spSach = driver.find_element(By.XPATH, '//*[@id="collection"]/div/div[2]/div/div[2]/div[4]/div[31]/div/div[2]/div[1]/h3/a')
    spSach.click()
    time.sleep(3)
    buttonHEART = driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_add"]')
    buttonHEART.click()

    #MỞ DANH SÁCH SẢN PHẨM YÊU THÍCH
    driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_page"]/a[2]').click()
    time.sleep(3)

    #KIỂM TRA HIỂN THỊ TÊN DANH SÁCH
    print(driver.find_element(By.XPATH, '//*[@id="onAppWishList_page"]/div[1]/div/div[1]/h1').text)

    #KIỂM TRA HIỂN THỊ ĐÚNG THÔNG TIN SẢN PHẨM (ẢNH, TÊN, GIÁ)
    wishlist = driver.find_elements(By.CSS_SELECTOR, 'div.pro-loop')
    for itemInfo in wishlist:
        image = itemInfo.find_element(By.CSS_SELECTOR, 'a>img').get_attribute('src')
        if(image != 'https://theme.hstatic.net/200000122283/1000637900/14/move.png?v=6544'):
            print(image)
            print(itemInfo.text)
            print('-----------------------------')
        else:
            break
except:
    print('Oops... ERROR, please run again.')

time.sleep(5)

