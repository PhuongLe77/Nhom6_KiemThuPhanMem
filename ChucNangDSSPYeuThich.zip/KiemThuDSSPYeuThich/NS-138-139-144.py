#KIỂM TRA KHI CHƯA ĐĂNG NHẬP
import time
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as exco
from selenium.common.exceptions import TimeoutException

try:
        driver = webdriver.Chrome(executable_path="venv/chromedriver.exe")
        driver.maximize_window()
        driver.get("https://nhanvan.vn/")
        time.sleep(3)

# -------------------------------KIỂM TRA KHI CHƯA YÊU THÍCH SẢN PHẨM NÀO-----------------------------------

        #MỞ DANH SÁCH SẢN PHẨM YÊU THÍCH
        driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_page"]/a[2]').click()

        #KIỂM TRA HIỂN THỊ TÊN DANH SÁCH
        print(driver.find_element(By.XPATH,'//*[@id="onAppWishList_page"]/div[1]/div/div[1]/h1').text)

        #KIỂM TRA HIỂN THỊ THÔNG BÁO DANH SÁCH RỖNG
        try:
            if(driver.find_element(By.XPATH,'//*[@id="onAppWishList_page"]/div[1]/div/div[3]/div')):
                print(driver.find_element(By.XPATH,'//*[@id="onAppWishList_page"]/div[1]/div/div[3]/div').text)
        except NoSuchElementException:
            print('No notification for list is null')

        #KIỂM TRA HIỂN THỊ DANH SÁCH RỖNG
        try:
            if (driver.find_element(By.XPATH, '//*[@id="onAppWishList_page"]/div[1]/div/div[3]/div/div/div[1]')):
                print('List is not null.')
        except NoSuchElementException:
            print('List is null.')

# -------------------------------KIỂM TRA KHI CÓ YÊU THÍCH SẢN PHẨM------------------------------------------

        #TÌM KIẾM SẢN PHẨM ĐỂ YÊU THÍCH
        driver.find_element(By.XPATH, '//*[@id="inputSearchAuto-dt"]').send_keys('Tha thứ cho những điều bạn không thể lãng quên')
        driver.find_element(By.XPATH, '//*[@id="searchsubmit"]').submit()
        time.sleep(3)
        driver.find_element(By.XPATH, '//*[@id="search"]/div[1]/div/div/div/div[2]/div[1]/h3/a').click()
        time.sleep(5)
        buttonHEART = driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_add"]')
        buttonHEART.click()
        time.sleep(3)

        #KIỂM TRA CÓ HIỂN THỊ THÔNG BÁO NGÕ LỜI YÊU CẦU NGƯỜI DÙNG ĐĂNG NHẬP
        try:
            WebDriverWait(driver, 3).until(exco.alert_is_present(), 'Alert is present')
            alert = driver.switch_to.alert
            alert.accept()
            print("Alert is accepted, User Login.")
        except TimeoutException:
            print("No alert for User to Login.")

        # MỞ DANH SÁCH SẢN PHẨM YÊU THÍCH
        driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_page"]/a[2]').click()
        time.sleep(3)

        #KIỂM TRA HIỂN THỊ TÊN DANH SÁCH
        print(driver.find_element(By.XPATH, '//*[@id="onAppWishList_page"]/div[1]/div/div[1]/h1').text)

        #KIỂM TRA HIỂN THỊ ĐÚNG THÔNG TIN SẢN PHẨM (ẢNH, TÊN, GIÁ)
        wishlist = driver.find_elements(By.CSS_SELECTOR, 'div.pro-loop')
        for itemInfo in wishlist:
            image = itemInfo.find_element(By.CSS_SELECTOR, 'a>img').get_attribute('src')
            if (image != 'https://theme.hstatic.net/200000122283/1000637900/14/move.png?v=6544'):
                print(image)
                print(itemInfo.text)
                print('-----------------------------')
            else:
                break
except:
    print('Oops... ERROR, please run again.')

time.sleep(5)
driver.close()

