#KIỂM THỬ NHẤN BUTTON XÓA TẤT CẢ KHI DANH SÁCH RỖNG
import time
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as exco
from selenium.common.exceptions import TimeoutException

try:
        driver = webdriver.Chrome(executable_path="venv/chromedriver.exe")
        driver.maximize_window()
        driver.get("https://nhanvan.vn/")
        time.sleep(3)

        #MỞ DANH SÁCH SẢN PHẨM YÊU THÍCH (CẦN ĐẢM BẢO DANH SÁCH ĐANG RỖNG)
        driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_page"]/a[2]').click()
        time.sleep(3)

        #KIỂM TRA HIỂN THỊ DANH SÁCH RỖNG
        try:
            if (driver.find_element(By.XPATH, '//*[@id="onAppWishList_page"]/div[1]/div/div[3]/div/div/div[1]')):
                print('List is not null.')
        except NoSuchElementException:
            print('List is null.')

        #BẤM NÚT XÓA
        btDeleteAll = driver.find_element(By.XPATH, '//*[@id="onAppWishList_removeAll"]')
        btDeleteAll.click()
        print('Button was clicked.')

        #KIỂM TRA CÓ HIỂN THỊ THÔNG BÁO DANH SÁCH RỖNG KHÔNG THỂ XÓA
        try:
            WebDriverWait(driver, 3).until(exco.alert_is_present(), 'No products here to delete.')
            alert = driver.switch_to.alert
            alert.accept()
            print("Alert appeared.")
        except TimeoutException:
            print("No alert for: Can't Delete because List is null.")
except:
    print('Oops... ERROR, please run again.')

time.sleep(5)
driver.close()

