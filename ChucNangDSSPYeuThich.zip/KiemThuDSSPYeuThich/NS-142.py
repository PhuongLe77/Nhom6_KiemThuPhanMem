from selenium.webdriver.common.action_chains import ActionChains
import time
from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as exco
from selenium.common.exceptions import TimeoutException

try:
    driver = webdriver.Chrome(executable_path="venv/chromedriver.exe")
    driver.maximize_window()
    driver.get("https://nhanvan.vn/")
    time.sleep(3)

    #DI CHUỘT ĐỂ HIỂN THỊ TRÁI TIM BÊN NGOÀI
    element = driver.find_element(By.XPATH, '//*[@id="siêu-thị-sách-&-tiện-ích-nhân-văn"]/div[1]/div[1]/div/main/div[6]/div/div/div[2]/div[1]/div/div[3]/div/div/div')
    buttonHEART = driver.find_element(By.XPATH, '//*[@id="siêu-thị-sách-&-tiện-ích-nhân-văn"]/div[1]/div[1]/div/main/div[6]/div/div/div[2]/div[1]/div/div[3]/div/div/div/div[1]/div[2]/div[2]/a')
    action = ActionChains(driver)
    action.move_to_element(element).perform()
    buttonHEART.click()

    # LẤY THÔNG TIN SẢN PHẨM VỪA XEM
    print('-----------You have just seen this product----------------')
    proName = driver.find_element(By.XPATH, '//*[@id="productDetail"]/h1').text
    proPrice = driver.find_element(By.XPATH, '//*[@id="price-preview"]/span').text
    print(proName)
    print(proPrice)
    print('----------------------------------------------------------')

    #KIỂM TRA CÓ HIỂN THỊ THÔNG BÁO NGÕ LỜI ĐĂNG NHẬP
    try:
        WebDriverWait(driver, 3).until(exco.alert_is_present(), 'No products here to delete.')
        alert = driver.switch_to.alert
        alert.accept()
        print("Alert appeared.")
    except TimeoutException:
        print("No alert: Do you want to Login to protect your Wishlist?")

    #MỞ DANH SÁCH SẢN PHẨM YÊU THÍCH
    driver.find_element(By.XPATH, '//*[@id="onAppWishList_btn_page"]/a[2]').click()
    time.sleep(3)

    #KIỂM TRA HIỂN THỊ TÊN DANH SÁCH
    print(driver.find_element(By.XPATH, '//*[@id="onAppWishList_page"]/div[1]/div/div[1]/h1').text)

    #KIỂM TRA HIỂN THỊ THÔNG BÁO DANH SÁCH RỖNG
    try:
        if(driver.find_element(By.XPATH,'//*[@id="onAppWishList_page"]/div[1]/div/div[3]/div')):
            print(driver.find_element(By.XPATH,'//*[@id="onAppWishList_page"]/div[1]/div/div[3]/div').text)
    except NoSuchElementException:
        print('No notification for list is null')

except:
    print('Oops... ERROR, please run again.')

time.sleep(5)
driver.close()


